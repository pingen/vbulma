# WebpackBin project

## Start

`npm install`

`npm start`

Go to `localhost:3000`
